package com.springboot.ex3.SpringBootProject3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootProject3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
